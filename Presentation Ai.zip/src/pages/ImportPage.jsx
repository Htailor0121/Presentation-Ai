import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, FolderUp, Globe, Cloud, Plus } from "lucide-react";

const ImportPage = () => {
  const navigate = useNavigate();

  const importOptions = [
    {
      title: "Upload a file",
      description: ["PowerPoint PPTX", "Word docs", "PDFs"],
      color: "from-[#e8d9ff] to-[#d6b8ff]",
      icon: FolderUp,
      action: "Browse files",
    },
    {
      title: "Import from Drive",
      description: ["Google Slides", "Google Docs"],
      color: "from-[#d7e9ff] to-[#b8dcff]",
      icon: Cloud,
      action: "Search",
    },
    {
      title: "Import from URL",
      description: ["Webpages", "Blog posts or articles", "Notion docs (public only)"],
      color: "from-[#b8f3eb] to-[#9deee1]",
      icon: Globe,
      action: <Plus size={16} />,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f7ff] to-[#c3e5ff] flex flex-col items-center text-gray-800">
      {/* Back Button */}
      <div className="w-full max-w-6xl mt-6 px-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 rounded-full text-sm bg-white shadow hover:bg-gray-50 transition"
        >
          <ArrowLeft size={18} /> Back
        </button>
      </div>

      {/* Title */}
      <div className="text-center mt-12">
        <h1 className="text-4xl font-bold text-[#222]">Import with AI</h1>
        <p className="text-gray-600 mt-2 text-lg">
          Select the file you'd like to transform
        </p>
      </div>

      {/* Import Options */}
      <div className="flex flex-wrap justify-center gap-8 mt-12 px-6">
        {importOptions.map((item, i) => (
          <div
            key={i}
            className={`relative bg-gradient-to-b ${item.color} rounded-2xl shadow-md w-80 p-6 flex flex-col transition hover:scale-[1.02] hover:shadow-lg cursor-pointer`}
          >
            <item.icon size={40} className="text-gray-700 mb-4" />
            <h2 className="text-xl font-semibold mb-2">{item.title}</h2>
            <ul className="text-gray-700 text-sm mb-4 space-y-1">
              {item.description.map((desc, j) => (
                <li key={j} className="flex items-center gap-1">
                  <span className="text-green-600">✔</span> {desc}
                </li>
              ))}
            </ul>
            <div className="absolute bottom-6 right-6 text-blue-600 font-medium text-sm flex items-center gap-1 cursor-pointer">
              {typeof item.action === "string" ? (
                <>
                  {item.action}
                  <span className="text-lg">↗</span>
                </>
              ) : (
                item.action
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Fallback Option */}
      <p className="text-gray-600 mt-12">
        If your file isn’t supported, you can also{" "}
        <button
          onClick={() => navigate("/paste")}
          className="text-blue-600 underline hover:text-blue-700"
        >
          paste in text
        </button>
      </p>

      {/* Recent Prompts Section */}
      <div className="text-center mt-16 mb-20">
        <h2 className="text-lg font-semibold text-gray-700">
          Your recent prompts
        </h2>
        <p className="text-gray-500 mt-2 text-sm">Coming soon...</p>
      </div>
    </div>
  );
};

export default ImportPage;
