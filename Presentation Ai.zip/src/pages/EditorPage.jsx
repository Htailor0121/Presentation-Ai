// --- imports remain same ---
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import ThemeSelector from "../components/ThemeSelector"; // ✅ Import ThemeSelector
import {
  Save,
  Eye,
  Download,
  Plus,
  Type,
  Image as ImageIcon,
  Search,
  BarChart2,
  Layout,
  Sparkles,
  HelpCircle,
  RefreshCcw,
} from "lucide-react";

// 🌈 All Available Gradient Themes
const gradientThemes = {
  "classic-light": {
    background: "linear-gradient(135deg, #ffffff, #f3f4f6)",
    color: "#1f2937",
  },
  "classic-dark": {
    background: "linear-gradient(135deg, #0f172a, #1e293b)",
    color: "#f9fafb",
  },
  sunset: {
    background: "linear-gradient(135deg, #ff6a00, #ee0979)",
    color: "#ffffff",
  },
  aqua: {
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#ffffff",
  },
  cyber: {
    background: "linear-gradient(135deg, #8e2de2, #4a00e0)",
    color: "#ffffff",
  },
  mint: {
    background: "linear-gradient(135deg, #00b09b, #96c93d)",
    color: "#ffffff",
  },
  peach: {
    background: "linear-gradient(135deg, #ffe259, #ffa751)",
    color: "#000000",
  },
  galaxy: {
    background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
    color: "#ffffff",
  },
  matrix: {
    background: "linear-gradient(135deg, #000000, #00ff88)",
    color: "#00ff88",
  },
  lavender: {
    background: "linear-gradient(135deg, #a18cd1, #fbc2eb)",
    color: "#1f2937",
  },
};


const EditorPage = () => {
  const location = useLocation();
  const outline = location.state?.outline || [];

  // 🌟 States
  const [slides, setSlides] = useState([]);
  const [selectedSlide, setSelectedSlide] = useState(null);
  const [editingTitle, setEditingTitle] = useState(false);
  const [editingContent, setEditingContent] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [currentTheme, setCurrentTheme] = useState("classic-dark");

  // 🧠 Load saved theme (if any)
  useEffect(() => {
    const savedTheme = localStorage.getItem("presentationTheme");
    if (savedTheme && gradientThemes[savedTheme]) {
      setCurrentTheme(savedTheme);
    }
  }, []);

  // 💾 Save theme on change
  useEffect(() => {
    localStorage.setItem("presentationTheme", currentTheme);
  }, [currentTheme]);

  // 🧠 Initialize slides from outline
  useEffect(() => {
    if (outline.length > 0) {
      const formattedSlides = outline.map((item, i) => ({
        id: i + 1,
        title: item.title || `Slide ${i + 1}`,
        content: item.content || "Generated AI Slide Content",
        imageUrl: item.imagePrompt?.startsWith("http")
          ? item.imagePrompt
          : `https://image.pollinations.ai/prompt/${encodeURIComponent(
              item.imagePrompt || item.title
            )}`,
        layout: item.layout || "left",
      }));
      setSlides(formattedSlides);
      setSelectedSlide(formattedSlides[0]);
    }
  }, [outline]);

  // 🧩 Handlers
  const handleSave = () => alert("✅ Presentation saved successfully!");
  const handleExport = () => alert("📦 Exporting presentation...");
  const handlePreview = () => alert("👀 Preview mode coming soon!");
  const handleAddSlide = () => {
    const newSlide = {
      id: slides.length + 1,
      title: `New Slide ${slides.length + 1}`,
      content: "Add your content here...",
      imageUrl: "",
      layout: "left",
    };
    setSlides([...slides, newSlide]);
    setSelectedSlide(newSlide);
  };
  const handleChangeLayout = () => {
    if (!selectedSlide) return;
    const newLayout =
      selectedSlide.layout === "left"
        ? "right"
        : selectedSlide.layout === "right"
        ? "center"
        : "left";
    const updatedSlides = slides.map((s) =>
      s.id === selectedSlide.id ? { ...s, layout: newLayout } : s
    );
    setSlides(updatedSlides);
    setSelectedSlide({ ...selectedSlide, layout: newLayout });
  };
  const handleChangeImage = () => {
    if (!selectedSlide) return;
    const newUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      selectedSlide.title + " illustration"
    )}`;
    const updatedSlides = slides.map((s) =>
      s.id === selectedSlide.id ? { ...s, imageUrl: newUrl } : s
    );
    setSlides(updatedSlides);
    setSelectedSlide({ ...selectedSlide, imageUrl: newUrl });
  };
  const handleEnhance = () => alert("✨ AI Enhanced the slide (mock)");
  const handleAddChart = () => {
    if (!selectedSlide) return;
    const newContent =
      selectedSlide.content +
      "\n\n📊 [AI Chart Placeholder: Replace with real chart data]";
    const updatedSlides = slides.map((s) =>
      s.id === selectedSlide.id ? { ...s, content: newContent } : s
    );
    setSlides(updatedSlides);
    setSelectedSlide({ ...selectedSlide, content: newContent });
  };

  // 🎨 Theme applied here
  return (
    <div
  className="min-h-screen flex flex-col transition-all duration-700"
  style={{
    background: gradientThemes[currentTheme].background,
    color: gradientThemes[currentTheme].color,
  }}
>

      {/* 🧭 Header */}
      <header className="flex items-center justify-between px-8 py-3 bg-black/30 backdrop-blur-md border-b border-white/10">
        <div className="flex items-center gap-3">
          <h1 className="text-lg font-semibold">
            {selectedSlide?.title || "Presentation"}
          </h1>
        </div>

        <div className="flex items-center gap-4 relative">
          {/* 🎨 Theme Selector */}
          <div className="relative">
            <button
              onClick={() => setShowThemeSelector(!showThemeSelector)}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition"
            >
              🎨 Theme
            </button>

            {showThemeSelector && (
              <div className="absolute right-0 mt-2 bg-black/80 backdrop-blur-xl border border-white/20 rounded-xl p-4 shadow-2xl z-50 w-72">
                <ThemeSelector
                  selected={currentTheme}
                  onChange={(themeId) => {
                    setCurrentTheme(themeId);
                    setShowThemeSelector(false);
                  }}
                />
              </div>
            )}
          </div>

          <button
            onClick={handleSave}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition"
          >
            <Save size={16} /> Save
          </button>
          <button
            onClick={handlePreview}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition"
          >
            <Eye size={16} /> Preview
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition"
          >
            <Download size={16} /> Export
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* 📑 Left Sidebar */}
        <aside className="w-64 bg-black/20 border-r border-white/10 overflow-y-auto">
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
            <h2 className="text-sm font-semibold">Slides</h2>
            <button
              onClick={handleAddSlide}
              className="text-xs bg-white/10 hover:bg-white/20 px-2 py-1 rounded flex items-center gap-1"
            >
              <Plus size={12} /> New
            </button>
          </div>
          <div>
            {slides.map((slide) => (
              <div
                key={slide.id}
                onClick={() => setSelectedSlide(slide)}
                className={`px-4 py-3 text-sm cursor-pointer border-b border-white/5 ${
                  selectedSlide?.id === slide.id
                    ? "bg-white/20"
                    : "hover:bg-white/10"
                }`}
              >
                <h3 className="font-medium truncate">{slide.title}</h3>
                <p className="text-xs opacity-70 truncate">{slide.content}</p>
              </div>
            ))}
          </div>
        </aside>

        {/* 🖋️ Main Editor */}
        <main className="flex-1 flex items-center justify-center p-10 relative">
          {selectedSlide ? (
            <motion.div
              key={selectedSlide.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="w-full max-w-6xl aspect-video rounded-2xl shadow-2xl flex overflow-hidden transition-all"
              style={{
                background: gradientThemes[currentTheme].background,
                color: gradientThemes[currentTheme].color,
              }}

            >
              {/* Text Section */}
              <div
                className={`flex-1 flex flex-col justify-center px-10 py-8 text-left ${
                  selectedSlide.layout === "right" ? "order-2" : "order-1"
                }`}
              >
                {editingTitle ? (
                  <input
                    value={selectedSlide.title}
                    onChange={(e) =>
                      setSelectedSlide({
                        ...selectedSlide,
                        title: e.target.value,
                      })
                    }
                    onBlur={() => setEditingTitle(false)}
                    className="text-4xl font-bold mb-4 bg-transparent border-b border-white/20 focus:outline-none"
                  />
                ) : (
                  <h2
                    className="text-4xl font-bold mb-4 cursor-text"
                    onClick={() => setEditingTitle(true)}
                  >
                    {selectedSlide.title}
                  </h2>
                )}

                {editingContent ? (
                  <textarea
                    value={selectedSlide.content}
                    onChange={(e) =>
                      setSelectedSlide({
                        ...selectedSlide,
                        content: e.target.value,
                      })
                    }
                    onBlur={() => setEditingContent(false)}
                    className="text-lg opacity-90 leading-relaxed bg-transparent border-b border-white/20 focus:outline-none h-40"
                  />
                ) : (
                  <p
                    className="text-lg opacity-90 leading-relaxed cursor-text whitespace-pre-line"
                    onClick={() => setEditingContent(true)}
                  >
                    {selectedSlide.content}
                  </p>
                )}
              </div>

              {/* Image Section */}
              {selectedSlide.imageUrl && (
                <div
                  className={`flex-1 flex items-center justify-center bg-black/20 ${
                    selectedSlide.layout === "right" ? "order-1" : "order-2"
                  }`}
                >
                  <img
                    src={selectedSlide.imageUrl}
                    alt="Slide Visual"
                    className="w-full h-full object-cover rounded-r-2xl"
                  />
                </div>
              )}
            </motion.div>
          ) : (
            <p className="text-gray-400 text-lg">
              Select or create a slide to begin editing
            </p>
          )}

          {/* 🧭 Floating Toolbar */}
          <div className="absolute right-10 top-1/2 -translate-y-1/2 flex flex-col items-center gap-6 bg-black/50 backdrop-blur-2xl p-5 rounded-3xl border border-white/10 shadow-2xl">
            {[
              { icon: <Search size={26} />, action: () => alert("🔍 Coming soon") },
              { icon: <Type size={26} />, action: () => setEditingTitle(true) },
              { icon: <ImageIcon size={26} />, action: handleChangeImage },
              { icon: <Plus size={26} />, action: handleAddSlide },
              { icon: <BarChart2 size={26} />, badge: "NEW", action: handleAddChart },
              { icon: <Layout size={26} />, action: handleChangeLayout },
              { icon: <Sparkles size={26} />, action: handleEnhance },
              { icon: <RefreshCcw size={26} />, action: () => window.location.reload() },
            ].map((btn, i) => (
              <button
                key={i}
                onClick={btn.action}
                className="relative group p-3 rounded-2xl bg-white/5 hover:bg-white/15 transition-all hover:scale-110 text-white"
              >
                {btn.icon}
                {btn.badge && (
                  <span className="absolute -top-2 -right-2 bg-green-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                    {btn.badge}
                  </span>
                )}
              </button>
            ))}
            <div className="mt-2 text-sm font-semibold text-gray-300">84%</div>
            <button className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition">
              <HelpCircle size={22} />
            </button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default EditorPage;
