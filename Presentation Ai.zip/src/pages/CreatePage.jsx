import React from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CreatePage = () => {
  const navigate = useNavigate();

  const cards = [
    {
      title: "Paste in text",
      desc: "Create from notes, an outline, or existing content",
      img: "/assets/paste.png", // replace with your own
      path: "/paste",
    },
    {
      title: "Generate",
      desc: "Create from a one-line prompt in a few seconds",
      img: "/assets/generate.png",
      path: "/generate",
    },
    {
      title: "Import file or URL",
      desc: "Enhance existing docs, presentations, or webpages",
      img: "/assets/import.png",
      path: "/import",
    },
  ];

  const recents = [
    { title: "vpn", time: "1 hour ago" },
    { title: "ai in health", time: "3 hours ago" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fafafa] to-[#c9e4ff] text-gray-800">
      {/* Back Button */}
      <div className="p-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Home
        </button>
      </div>

      {/* Title Section */}
      <div className="text-center mt-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-bold text-gray-900"
        >
          Create with AI
        </motion.h1>
        <p className="text-gray-600 mt-2 text-lg">
          How would you like to get started?
        </p>
      </div>

      {/* Option Cards */}
      <div className="flex flex-col md:flex-row items-center justify-center gap-6 mt-12 px-6">
        {cards.map((card, i) => (
          <motion.div
            key={i}
            whileHover={{ y: -6 }}
            transition={{ type: "spring", stiffness: 300 }}
            className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-xs cursor-pointer hover:shadow-xl transition"
            onClick={() => navigate(card.path)}
          >
            <img
              src={card.img}
              alt={card.title}
              className="w-full rounded-xl mb-4"
            />
            <h3 className="font-semibold text-lg text-gray-900">
              {card.title}
            </h3>
            <p className="text-gray-500 mt-2 text-sm">{card.desc}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent Prompts */}
      <div className="text-center mt-16">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">
          Your recent prompts
        </h2>
        <div className="flex flex-col items-center gap-3">
          {recents.map((item, i) => (
            <div
              key={i}
              className="bg-white w-full max-w-lg rounded-xl shadow p-4 flex justify-between items-center hover:shadow-md transition"
            >
              <span className="font-medium text-gray-800">{item.title}</span>
              <span className="text-sm text-gray-500">Generated · {item.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CreatePage;
