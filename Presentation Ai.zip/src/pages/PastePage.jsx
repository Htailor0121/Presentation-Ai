import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, FileText, Globe, File, Smartphone } from "lucide-react";

const PastePage = () => {
  const navigate = useNavigate();
  const [type, setType] = useState("Presentation");
  const [theme, setTheme] = useState("Default");
  const [content, setContent] = useState("");

  const types = [
    { name: "Presentation", icon: FileText },
    { name: "Webpage", icon: Globe },
    { name: "Document", icon: File },
    { name: "Social", icon: Smartphone },
  ];

  const handleGenerate = () => {
    if (!content.trim()) return alert("Please paste or type some content first!");
    // Send content + preferences to next page
    navigate("/outline", {
      state: {
        content,
        type,
        theme,
      },
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f7ff] to-[#c3e5ff] flex flex-col items-center text-gray-800">
      {/* Back Button */}
      <div className="w-full max-w-6xl mt-6 px-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 rounded-full text-sm bg-white shadow hover:bg-gray-50 transition"
        >
          <ArrowLeft size={18} /> Back
        </button>
      </div>

      {/* Title */}
      <div className="text-center mt-10">
        <h1 className="text-4xl font-bold text-[#002b5b] flex items-center justify-center gap-2">
          <FileText className="text-blue-500" /> Paste in text
        </h1>
        <p className="text-gray-600 mt-2 text-lg">
          What would you like to create?
        </p>
      </div>

      {/* Type Selection */}
      <div className="flex gap-4 mt-8 flex-wrap justify-center">
        {types.map((item) => (
          <button
            key={item.name}
            onClick={() => setType(item.name)}
            className={`flex flex-col items-center justify-center w-36 h-24 rounded-xl border transition ${
              type === item.name
                ? "bg-white border-blue-400 shadow-md"
                : "bg-white/60 border-gray-200 hover:bg-white"
            }`}
          >
            <item.icon
              size={28}
              className={type === item.name ? "text-blue-600" : "text-gray-500"}
            />
            <span className="mt-2 font-medium">{item.name}</span>
          </button>
        ))}
      </div>

      {/* Theme Dropdown */}
      <div className="mt-6">
        <select
          value={theme}
          onChange={(e) => setTheme(e.target.value)}
          className="px-4 py-2 rounded-lg border bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
        >
          <option>Default</option>
          <option>Professional</option>
          <option>Minimal</option>
          <option>Creative</option>
        </select>
      </div>

      {/* Main Input Section */}
      <div className="flex flex-col lg:flex-row gap-8 mt-12 w-full max-w-6xl px-6">
        {/* Text Input Area */}
        <div className="flex-1 bg-white rounded-2xl shadow-lg p-6 min-h-[300px]">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Type or paste your notes, outline, or content here..."
            className="w-full h-64 outline-none resize-none text-gray-700"
          ></textarea>
        </div>

        {/* Optional Info Card */}
        <div className="w-full lg:w-80 bg-white rounded-2xl shadow-lg p-6">
          <h3 className="font-semibold text-gray-800 flex items-center gap-2">
            💡 Optional: card-by-card control
          </h3>
          <p className="text-sm text-gray-600 mt-2">
            Know what you want on each card? Add three dashes (<code>---</code>) between
            sections.
          </p>

          <div className="mt-4 bg-gray-50 p-3 rounded-lg text-sm text-gray-700">
            <p>Intro to our new strategy</p>
            <ul className="list-disc list-inside text-gray-600 text-sm">
              <li>Key point 1</li>
              <li>Key point 2</li>
              <li>Key point 3</li>
            </ul>
            <p className="mt-2">---</p>
            <p className="mt-2">Key metrics from Q1</p>
            <ul className="list-disc list-inside text-gray-600 text-sm">
              <li>Key point 1</li>
              <li>Key point 2</li>
              <li>Key point 3</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <div className="mt-10 mb-16">
        <button
          onClick={handleGenerate}
          className="bg-blue-600 text-white px-8 py-3 rounded-full font-medium shadow hover:bg-blue-700 transition flex items-center gap-2"
        >
          Generate Outline
        </button>
      </div>
    </div>
  );
};

export default PastePage;
