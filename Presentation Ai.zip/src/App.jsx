import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Header from "./components/Header";
import CreatePage from "./pages/CreatePage";
import GeneratePage from "./pages/GeneratePage"; // ✅ ADD THIS LINE
import GeneratedOutlinePage from "./pages/GeneratedOutlinePage";
import EditorPage from "./pages/EditorPage";
import ImportPage from "./pages/ImportPage"; // ✅ Added Import Page
import PastePage from "./pages/PastePage";
import { PresentationProvider } from "./context/PresentationContext";

function AppContent() {
  const location = useLocation();
  const showHeader = location.pathname === "/"; // ✅ Only show header on homepage

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f9fafb] to-[#dbeafe]">
      {showHeader && <Header />}
      <main>
        <Routes>
          <Route path="/" element={<CreatePage />} />
          <Route path="/generate" element={<GeneratePage />} /> {/* ✅ Fixed import */}
          <Route path="/outline" element={<GeneratedOutlinePage />} />
          <Route path="/editor" element={<EditorPage />} />
          <Route path="/editor/:id" element={<EditorPage />} />
          <Route path="/import" element={<ImportPage />} /> {/* ✅ New Route */}
          <Route path="/paste" element={<PastePage />} />
        </Routes>
      </main>

      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: "#363636",
            color: "#fff",
          },
        }}
      />
    </div>
  );
}

function App() {
  return (
    <PresentationProvider>
      <Router>
        <AppContent />
      </Router>
    </PresentationProvider>
  );
}

export default App;
